package com.jwttokendemo.model;


import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class User {
    String token;


}
