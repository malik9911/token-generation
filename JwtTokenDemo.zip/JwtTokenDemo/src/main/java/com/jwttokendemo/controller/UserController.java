package com.jwttokendemo.controller;

import com.jwttokendemo.config.JwtUtil;
import com.jwttokendemo.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
    @Autowired
    JwtUtil jwtUtil;

    @PostMapping("/token")
    public User login(@RequestBody String userName) {
       String token= jwtUtil.generateToken(userName);
      return User.builder().token(token).build();
    }
    }
