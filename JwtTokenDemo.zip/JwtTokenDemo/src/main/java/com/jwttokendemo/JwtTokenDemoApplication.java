package com.jwttokendemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtTokenDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtTokenDemoApplication.class, args);
	}

}
